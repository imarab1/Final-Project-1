# FinalCS1
## Author: Imara Bhanji
### The Chemistry Game!

#### Game Description!
This program is a simple question and answer game on the super fun topic of cheimstry, specifically the periodic table. The player is given a choice between two types of questions. In the first game the player is given the element abriviation is given and the player must answer with the correct atomic weight and element name.
Then in the second part of the game, the user is given a the atomic mass of an element, and they must guess the correct elements. For the second question, they are given the atomic mass and element, with that they must guess the correct atomic number.

#### What is needed to run the program!
This program requires the download of two other files that have been attached in this github. The first being Element.java, this is an object file that we call into our main method. The second is elements.txt, this is the file that stores all of our elements. Our main file is FinalProject.java. All of these files must be in the same file. That sounds a bit confusing, all that this means that one file can't be in documents while the other is download. 

After that you should be able to run the code, and play the game! Good Luck!






